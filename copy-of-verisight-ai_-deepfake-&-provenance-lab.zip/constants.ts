
export const APP_THEME = {
  primary: '#3b82f6', // blue-500
  secondary: '#0f172a', // slate-900
  background: '#020617', // slate-950
  danger: '#ef4444', // red-500
  success: '#10b981', // emerald-500
};

export const MOCK_GENESIS_HASH = "0x892c903219154310f970ab9eacda6e6f";
