
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from "../types";

export const analyzeMedia = async (base64Data: string, mimeType: string): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Analyze this media carefully for signs of AI generation or deepfake manipulation.
    Check for:
    - Lighting inconsistencies
    - Blur patterns in facial features (eyes, teeth)
    - Background warping
    - Unnatural textures
    - Digital artifacts (JPEG double compression, aliasing)
    
    Provide a detailed JSON response including:
    1. isDeepfake (boolean)
    2. confidence (0-100)
    3. analysisLog (list of specific observations)
    4. artifacts (specific issues found)
    5. metadata (guessed format, resolution, likely source)
    6. A simulated "Digital Provenance Chain" of 3-4 steps based on standard C2PA (Content Authenticity Initiative) data if it were a real authenticated file, OR a chain showing where the signature was lost if it's a deepfake.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          { inlineData: { data: base64Data, mimeType } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isDeepfake: { type: Type.BOOLEAN },
            confidence: { type: Type.NUMBER },
            analysisLog: { type: Type.ARRAY, items: { type: Type.STRING } },
            artifacts: { type: Type.ARRAY, items: { type: Type.STRING } },
            metadata: {
              type: Type.OBJECT,
              properties: {
                format: { type: Type.STRING },
                resolution: { type: Type.STRING },
                sourceGuess: { type: Type.STRING }
              },
              required: ["format", "resolution", "sourceGuess"]
            },
            provenance: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  timestamp: { type: Type.STRING },
                  action: { type: Type.STRING },
                  entity: { type: Type.STRING },
                  hash: { type: Type.STRING },
                  location: { type: Type.STRING },
                  status: { type: Type.STRING }
                },
                required: ["id", "timestamp", "action", "entity", "hash", "status"]
              }
            }
          },
          required: ["isDeepfake", "confidence", "analysisLog", "artifacts", "metadata", "provenance"]
        }
      }
    });

    const result = JSON.parse(response.text);
    return result as AnalysisResult;
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    throw error;
  }
};
